import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  demandes: any ; 
  pret: any ; 
  attente: any ; 
  preparation: any;
  constructor(private http: HttpClient) { 
    
    this.http.get('http://localhost:8080/demande/countall')
    .subscribe(response =>{      
      this.demandes = response as any ;
    });
    this.http.get('http://localhost:8080/demande/countpret')
    .subscribe(response =>{      
      this.pret = response as any ;
    });
    this.http.get('http://localhost:8080/demande/countattente')
    .subscribe(response =>{      
      this.attente = response as any ;
    });
    this.http.get('http://localhost:8080/demande/countpreparation')
    .subscribe(response =>{      
      this.preparation = response as any ;
    });

 
  }

  ngOnInit(): void {
  }

}
