import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addplat',
  templateUrl: './addplat.component.html',
  styleUrls: ['./addplat.component.css']
})
export class AddplatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
