import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateplat',
  templateUrl: './updateplat.component.html',
  styleUrls: ['./updateplat.component.css']
})
export class UpdateplatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
