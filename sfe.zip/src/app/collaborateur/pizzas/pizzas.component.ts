import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { TokenStorageService } from 'src/app/auth/token-storage.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'pizzas',
  templateUrl: './pizzas.component.html',
  styleUrls: ['./pizzas.component.css']
})
export class PizzasComponent implements OnInit {

     
  posts:any [] = [];
  images:any [] = [];
  new:any [] = [];
  retrievedImage = 'data:image/jpeg;base64,';
  username ;

constructor(private http: HttpClient,private token: TokenStorageService) {
 this.username = this.token.getUsername() ;
 this.http.get('http://localhost:8080/plat/getplatnotfavoris/3/'+this.username)
 .subscribe(response =>{      
   this.posts = response as any ;
 })

}

ngOnInit(): void {
}

onClick(post){
this.http.post('http://localhost:8080/favoris/addfavoris/', {id_plat: post,username: this.username})
.subscribe(re =>{
 this.http.get('http://localhost:8080/plat/getplatnotfavoris/3/'+this.username)
 .subscribe(response =>{      
   this.posts = response as any ;
 })
});}

onClickdelete(post){
 this.http.delete('http://localhost:8080/favoris/deletefavoris/'+post+'/'+this.username)
 .subscribe(ra =>{
   this.http.get('http://localhost:8080/plat/getplatnotfavoris/3/'+this.username)
   .subscribe(response =>{      
     this.posts = response as any ;
   })
});}

adddemande(post,nom){
 this.http.post('http://localhost:8080/demande/adddemande', {id_plat: post,username: this.username,etat: 'en attente',nomplat: nom})
 .subscribe(re =>{
});

Swal.fire({
 position: 'top-end',
 icon: 'success',
 title: 'La demande est effectuée avec succès',
 showConfirmButton: false,
 timer: 1500  
})

}


}
