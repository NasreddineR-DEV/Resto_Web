export interface Plat {
    id_Plat: number;
    nom_Plat: String;
    prix: number;
    id_Menu: number
}