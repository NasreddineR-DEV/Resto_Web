export interface Demande {
    id_demande: number;
    id_plat: number;
    username: string;
    etat: string;
    nomplat: string;
}